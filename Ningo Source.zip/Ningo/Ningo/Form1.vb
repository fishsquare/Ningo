﻿Public Class Form1
    Dim Hunger As Integer = 25
    Dim Thirst As Integer = 25
    Dim Health As Integer = 25
    Dim Food As Integer = 25
    Dim Drink As Integer = 25
    Dim Pill As Integer = 0
    Dim Credits As Integer = 20
    Dim Bypass As Boolean = False

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Food = 0 Then

        Else
            If Hunger < 90 Then
                Hunger = Hunger + 5
            End If
            If Health < 90 Then
                Health = Health + 2
            End If
            If Thirst > 10 Then
                Thirst = Thirst - 1
            End If
            Food = Food - 1
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Drink = 0 Then

        Else
            If Thirst < 90 Then
                Thirst = Thirst + 5
            End If
            If Health < 90 Then
                Health = Health + 2
            End If
            If Hunger < 90 Then
                Hunger = Hunger + 1
            End If
            Drink = Drink - 1
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        HeartTimer.Start()
        UpdateTimer.Start()
    End Sub

    Private Sub UpdateTimer_Tick(sender As Object, e As EventArgs) Handles UpdateTimer.Tick
        HProgressBar.Value = Hunger
        TProgressBar.Value = Thirst
        HeProgressBar.Value = Health
        Label4.Text = "x " & Food
        Label5.Text = "x " & Drink
        Label10.Text = "x " & Pill
        Label8.Text = Hunger & "%"
        Label7.Text = Thirst & "%"
        Label6.Text = Health & "%"
        Button6.Text = "Food x " & Food & " | Buy 1"
        Button8.Text = "Drink x " & Drink & " | Buy 1"
        Button5.Text = "Pill x " & Pill & " | Buy 1"
        Label9.Text = "Credits: " & Credits & "C"
    End Sub

    Private Sub HeartTimer_Tick(sender As Object, e As EventArgs) Handles HeartTimer.Tick
        If Health < 3 Then
            UpdateTimer.Stop()
            HeartTimer.Stop()
            Health = 25
            MessageBox.Show("Your Pet has died", "Your Pet has died", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Hunger = 25
            Thirst = 25
            Food = 25
            Drink = 25
            UpdateTimer.Start()
            HeartTimer.Start()
        Else
            Health = Health - 1
        End If
        If Thirst > 10 Then
            Thirst = Thirst - 1
        End If
        If Hunger > 10 Then
            Hunger = Hunger - 1
        End If
        If Hunger < 20 Then
            Health = Health - 1
        End If
        If Thirst < 20 Then
            Health = Health - 1
        End If

        If Thirst > 80 Then
            Credits = Credits + 1
        End If
        If Hunger > 80 Then
            Credits = Credits + 1
        End If
        If Health > 80 Then
            Credits = Credits + 2
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Panel1.Visible = True Then
            Button2.Text = "Toggle Shop 0"
            Panel1.Visible = False
        Else
            Button2.Text = "Toggle Shop 1"
            Panel1.Visible = True
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If Credits < 2 Then
            MessageBox.Show("You cannot afford this", "You cannot afford this", MessageBoxButtons.OK)
        Else
            Credits = Credits - 2
            Food = Food + 1
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If Credits < 1 Then
            MessageBox.Show("You cannot afford this", "You cannot afford this", MessageBoxButtons.OK)
        Else
            Credits = Credits - 1
            Drink = Drink + 1
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Pill = 0 Then

        Else
            If Hunger > 10 Then
                Hunger = Hunger - 2
            End If
            If Health < 90 Then
                Health = Health + 5
            End If
            If Thirst > 10 Then
                Thirst = Thirst - 2
            End If
            Pill = Pill - 1
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If Credits < 5 Then
            MessageBox.Show("You cannot afford this", "You cannot afford this", MessageBoxButtons.OK)
        Else
            Credits = Credits - 5
            Pill = Pill + 1
        End If
    End Sub

    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportToolStripMenuItem.Click
        NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
        NotifyIcon1.BalloonTipText = "Hunger = " & Hunger & Environment.NewLine &
            "Thirst = " & Thirst & Environment.NewLine &
            "Health = " & Health & Environment.NewLine &
            "Food x" & Food & Environment.NewLine &
            "Drink x" & Drink & Environment.NewLine &
            "Pill x" & Pill
        NotifyIcon1.ShowBalloonTip(5000)
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If Bypass = False Then
            Me.Visible = False
            e.Cancel = True
        End If
    End Sub

    Private Sub ShowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Bypass = True
        Application.Exit()
    End Sub
End Class
